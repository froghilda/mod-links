﻿# RRR Monsters

- Adds new enemies to the game, with more to come in future updates.
  

- **Note: Alone, this mod only adds the enemies to the game, it does not actually use or spawn them anywhere.** 
  

- **To make proper use of this mod, you will need my other mods [RRR Better Raids](https://github.com/astradamus/RRRBetterRaids) and/or [RRR Spawn Variety](https://github.com/astradamus/RRRSpawnVariants), which are already fully configured to work with this mod without additional work.**
  

- You can also use any other mod that enables custom mob spawns or custom raids, provided you can configure them yourself. Prefab IDs for the mobs included in this mod are listed below.

## Setup

Extract the zip file to your `Valheim\BepInEx` folder. Config files should end up in `Valheim\BepInEx\config`, everything else should end up in `Valheim\BepInEx\plugins`. Config files will also be generated automatically if missing.

## Help!

If you need further assistance, feel free to bug me in the Valheim Modding Discord at https://discord.gg/RBq2mzeu4z

#### Added Prefab IDs
```
RRR_GDThornweaver
RRR_GhostVengeful
RRR_TrollTosser
```