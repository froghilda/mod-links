﻿# RRR Non-Player Characters

### ***Now with Custom NPC configs, design your own NPCs in configs and use them with console spawn or any other mod that spawns mobs! See below.***

- Adds non-player humans to the game, currently only enemies.
  

- **Note: Alone, this mod only adds the NPCs to the game, it does not actually use or spawn them anywhere.** 
  

- **To make proper use of this mod, you will need my other mods [RRR Better Raids](https://github.com/astradamus/RRRBetterRaids) and/or [RRR Spawn Variety](https://github.com/astradamus/RRRSpawnVariants), which are already fully configured to work with this mod without additional work.**
  

- You can also use any other mod that enables custom mob spawns or custom raids, provided you can configure them yourself. Prefab IDs for the mobs included in this mod are listed below.

## Custom NPCs

- This feature is currently rather basic, but many users reached out to ask for a way to have non-hostile NPCs they can add to their worlds for RP purposes, even if they are not (yet!) capable of anything more than standing around, looking slick and defending the area.


- Currently you can set display name, damage, health, faction (who they attack), equip them with any player weapons or armor, and configure their sex/beard/hair/colors/etc.


- Everything is explained and demonstrated in the Configs for the mod. There is an example config as well. If you have any other questions feel free to ask. 

## Setup

Extract the zip file to your `Valheim\BepInEx` folder. Config files should end up in `Valheim\BepInEx\config`, everything else should end up in `Valheim\BepInEx\plugins`. Config files will also be generated automatically if missing.

## Help!

If you need further assistance, feel free to bug me in the Valheim Modding Discord at https://discord.gg/RBq2mzeu4z

#### Added Prefab IDs
- (Note: T1-T6 refers to progression tiers, Meadows > Forest > Swamp > Mountains > Plains > Endgame)
```
RRR_Hostile_T1
RRR_Hostile_T2
RRR_Hostile_T3
RRR_Hostile_T4
RRR_Hostile_T5
RRR_Hostile_T6
```